package com.his.dto;

import lombok.Data;

@Data
public class IncomeData {

	private Integer incomeId;
	private Double salaryIncome;
	private Double propertyIncome;
	private Integer appNumber;

}
