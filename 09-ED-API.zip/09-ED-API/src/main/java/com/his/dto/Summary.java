package com.his.dto;

import lombok.Data;

@Data
public class Summary {

	private Integer appNumber;

	private IncomeData incomeData;

	private EducationData educationData;

	private KIdsInfo kIdsInfo;

}